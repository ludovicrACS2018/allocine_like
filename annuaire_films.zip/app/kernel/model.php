<?php
class Model {
   
}