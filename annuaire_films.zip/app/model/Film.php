<?php

class Film extends Model {
    public $id, $description, $expiration, $slug;
    
    public static function getFromId($id) {
       $db = Database::getInstance();
       $sql = "SELECT * FROM film WHERE id_film = :id";
       $stmt = $db->prepare($sql);
       $stmt->bindValue(':id', $id, PDO::PARAM_INT);
       $stmt->execute();
       return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function getList() {
       $db = Database::getInstance();

       $sql = 'SELECT * FROM `film` ORDER BY RAND() LIMIT 6';
       $stmt = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);

       return $stmt;
    }
 }