<?php
class FilmController extends Controller {
    
    public function display() {
        $id = $this->route["params"]["id"];
        $film = Film::getFromId($id);
      
        $template = $this->twig->loadTemplate('/Film/display.html.twig');
        echo $this->twig->render($template, array(
            'film' => $film
        ));    

   }
}